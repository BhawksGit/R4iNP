#R4 2024 HK README
#Kernel Version: Ace3DS+_R4iLS_Wood_R4_1.62
#Distributed by Hawknetics
#Please refer to this file for any help with the installation of the kernel

To redownload the R4iNP kernel, visit www.R4iNP.com
Simply download the zip file and extract it directly into the microSD

The cart requires the files _rpg, _DS_MENU, and _DSMENU in order for it to work. All other files are optional and can be removed if desired

Please make a backup of the files in a separate folder on your computer if performing additional modifications

If you have any questions on usage, do not hesitate to contact me at brandon@hawknetics.com and I'll do my best to help